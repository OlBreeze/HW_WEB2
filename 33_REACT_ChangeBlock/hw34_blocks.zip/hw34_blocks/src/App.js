import Block from "./components/Block";

function App() {
    return (<Block/>);
}

export default App;

