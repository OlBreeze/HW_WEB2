import React from 'react';
import '../style/index.css';
import {colors} from "../utils/constants";

class Block extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            bigBlock: true,
            curColor: "red"
        };
    }

    handleOnClick = (event) => {
        const curColor = event.currentTarget.getAttribute("color");
        //console.log(event.currentTarget)
        this.setState({
            bigBlock: !this.state.bigBlock,
            curColor: curColor
        })
    };

    getBlock = ()=> {
        let innerBlock;

        if (this.state.bigBlock) {
            innerBlock = colors.map((value, index) => (
                <div key={index} className={`block size-small color_${value}`} color={value}  onClick={this.handleOnClick}></div>
            ));
        } else {
            innerBlock = <div className={`block size-big color_${this.state.curColor}`} color={this.state.curColor} onClick={this.handleOnClick}></div>;
        }

        return (
            <div className="block-container">
                {innerBlock}
            </div>
        );
    }

    render() {
        return this.getBlock();
    }
}

export default Block;