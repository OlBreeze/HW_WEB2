export const colorArr = ['red','green','blue','yellow'];
export const colorArr2 = ['pink','orange','purple','grey'];