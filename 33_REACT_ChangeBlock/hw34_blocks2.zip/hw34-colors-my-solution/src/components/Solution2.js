import React, {Component} from 'react';
import {colorArr2} from "../utils/constants";
import Block from "./Block";

class Solution2 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            color: ""
        }
    }

    changeColor = (color) => {
        this.setState({color: this.state.color? "" : color})

    }
    renderDefault = () => {
        return(
            <div className="block-container">
                {colorArr2.map((color) =>
                    <Block color={color} changeColor={this.changeColor} key={color} size={'block'}/>
                )}
            </div>
        )
    }
    renderColor = () => {
        return (<div className="block-container">
            <Block color={this.state.color} changeColor={this.changeColor} size={"big"}/>
        </div>)
    }

    render() {
       return this.state.color? this.renderColor() : this.renderDefault();
    }
}

export default Solution2;