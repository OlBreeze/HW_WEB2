import './App.css';
import Solution1 from "./components/Solution1";
import Solution2 from "./components/Solution2";

function App() {

    return (
        <><Solution1/>
            <Solution2/></>
    );
}

export default App;
