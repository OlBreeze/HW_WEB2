import './App.css';
import React, {Component} from "react";
import {GameContext} from "./utils/gameContext";
import Start from "./components/Start";
import Game from "./components/Game";
import FinishPage from "./components/FinishPage";
import {arrayNames} from "./utils/constants";

class App extends Component {
    #nameOwn;
    #username;
    #resultGame;
    #gameScore;

    constructor(props) {
        super(props);

        this.#nameOwn = false;
        this.#username = arrayNames[Math.floor(Math.random() * arrayNames.length)];
        this.#resultGame = '';
        this.#gameScore = '0-0';

        this.state = {
            activePage: 'Start'
        }
    }

    changePage = (page) => {
        const temp = {...this.state};
        temp.activePage = page;
        this.setState(temp);

        if (page === 'Start' && !this.#nameOwn)
            this.#username = arrayNames[Math.floor(Math.random() * arrayNames.length)];
    }

    changeName = (name) => {
        if (name && name !== this.#username) {
            this.#username = name;
            this.#nameOwn = true;
        }
    }

    changeResult = (result) => {
        this.#resultGame = result
    };

    changeScore = (result) => {
        this.#gameScore = result
    };


    render() {
        let curPage;
        if (this.state.activePage === 'Start')
            curPage = <Start/>
        else if (this.state.activePage === 'Game')
            curPage = <Game/>
        else if (this.state.activePage === 'Finish')
            curPage = <FinishPage/>


        return (
            <div className="App">

                <GameContext.Provider
                    value={{
                        nameOwn: this.#nameOwn,
                        username: this.#username,
                        result: this.#resultGame,
                        score: this.#gameScore,
                        changePage: this.changePage,
                        changeName: this.changeName,
                        changeResult: this.changeResult,
                        changeScore: this.changeScore,
                    }}>
                    {curPage}
                </GameContext.Provider>

            </div>

        );
    }
}

export default App;
