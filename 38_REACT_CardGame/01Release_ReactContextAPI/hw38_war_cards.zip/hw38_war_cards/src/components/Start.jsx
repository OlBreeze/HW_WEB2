import React from 'react';
import {GameContext} from "../utils/gameContext";
import style from './start.module.css';

class Start extends React.Component {
    constructor(props) {
        super(props);
        this.inpName = React.createRef();
    }

    render() {
        return (<GameContext.Consumer>
                {value =>
                    <div className={'container'}>
                        <h1>READY FOR BATTLE{value.nameOwn ? `, ${value.username}?` : ''}</h1>
                        <input className={style.inputStart} type="search" id='username' ref={this.inpName}
                               placeholder={'Enter your name'}/>
                        <div>
                            <div className={style.wrapBtnStart}>
                                <button className={style.btnStart}
                                        onClick={() => {
                                            value.changeName(this.inpName.current.value.trim());
                                            value.changePage('Game')
                                        }}>start
                                </button>
                            </div>
                        </div>
                    </div>}
            </GameContext.Consumer>
        );
    }
}

export default Start;