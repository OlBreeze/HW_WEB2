import React from 'react';
import {GameContext} from "../utils/gameContext";
import style from './finish.module.css';


const FinishPage = () => {
    return (
        <GameContext.Consumer>
            {value =>
                <div className={`container ${style.containerCards}`}>
                    <h1 className={style.h1}>{value.result}</h1>
                    <h2>Score: {value.score}</h2>
                    <div className={style.wrapBtnStart}>
                        <button className={style.btnStart} onClick={() => {
                            value.changePage('Start')
                        }}>Again?
                        </button>
                    </div>
                </div>}
        </GameContext.Consumer>
    )
        ;
};

export default FinishPage;