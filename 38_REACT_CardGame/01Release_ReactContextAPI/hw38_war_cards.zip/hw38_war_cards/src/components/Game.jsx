import React from 'react';
import {GameContext} from "../utils/gameContext";
import {cards, images, suit} from "../utils/constants";
import clickSoundWin from '../sounds/win.mp3';
import clickSoundLose from '../sounds/lose.mp3';


import style from './game.module.css';

class Game extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cardDeck: [],
            cardCPU: [0, 0],
            cardUser: [0, 0],
            winsCPU: 0,
            winsUser: 0
        }
        this.fillCardDeck(this.state.cardDeck);
    }

    fillCardDeck = (cardDeck) => {
        for (const cardItem of cards) {
            for (let i = 0; i < 4; i++) {
                cardDeck.push([cardItem, i]);
            }
        }
    }

    playGameNext = () => {
        const temp = {...this.state};
        // убрали карту цпу
        const randomIndexCPU = Math.floor(Math.random() * temp.cardDeck.length);
        temp.cardCPU = temp.cardDeck[randomIndexCPU];
        temp.cardDeck = temp.cardDeck.filter((item, index) => index !== randomIndexCPU);

        // убрали карту пользов
        const randomIndexUser = Math.floor(Math.random() * temp.cardDeck.length);
        temp.cardUser = temp.cardDeck[randomIndexUser];
        temp.cardDeck = temp.cardDeck.filter((item, index) => index !== randomIndexUser);

        if (temp.cardCPU[0] > temp.cardUser[0]) {
            temp.winsCPU++;
        } else if (temp.cardCPU[0] < temp.cardUser[0])
            temp.winsUser++;

        this.setState(temp);

        /// --- sound - + -
        if (temp.cardCPU[0] < temp.cardUser[0])
            this.playSound(clickSoundWin, 'audioWin');
        else if (temp.cardCPU[0] > temp.cardUser[0])
            this.playSound(clickSoundLose, 'audioLose');
        /// --- sound - - -
    }

    playSound = (sound, elem) => {
        try {
            const audioEl = document.getElementById(elem);
            audioEl.src = sound;
            audioEl.play();
        } catch (e) {
            console.log(e.message)
        }
    }

    render() {
        const imageCPU = images[`card_${this.state.cardCPU[0]}_${this.state.cardCPU[1]}`];
        const imgCPU = <img src={imageCPU} alt="card" className={style.imgClass}/>;

        const imageUser = images[`card_${this.state.cardUser[0]}_${this.state.cardUser[1]}`];
        const imgUser = <img src={imageUser} alt="card" className={style.imgClass}/>;

        return (
            <GameContext.Consumer>
                {value =>
                    <div className={'container'}>
                        <div className={style.containerCards}>
                            <div>
                                <h2>Computer: {this.state.winsCPU}</h2>
                                {imgCPU}
                            </div>
                            <div>
                                <h2>{value.username}: {this.state.winsUser}</h2>
                                {imgUser}
                            </div>
                        </div>

                        <div className={style.wrapBtnStart}>
                            <button className={style.btnStart} onClick={() => {
                                if (this.state.cardDeck.length === 0) {
                                    const result = (this.state.winsCPU < this.state.winsUser) ? 'You WON!' : (this.state.winsCPU > this.state.winsUser) ? 'You Lose' : 'Draw';
                                    value.changeResult(result);
                                    value.changeScore(`${this.state.winsCPU} - ${this.state.winsUser}`);
                                    value.changePage('Finish');
                                } else {
                                    this.playGameNext();
                                }
                            }}>Next
                            </button>
                        </div>
                        <audio id="audioWin" src={clickSoundWin}></audio>
                        <audio id="audioLose" src={clickSoundLose}></audio>

                    </div>
                }
            </GameContext.Consumer>
        );
    }
}

export default Game;