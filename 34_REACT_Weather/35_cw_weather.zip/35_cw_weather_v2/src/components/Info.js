import React from 'react';
import './info.css'
//rsc - shortcut for functional component
//rcc - for class component
const Info = () => {
    return (
        <div>
            <h2 className={'fontSize'}>Weather forecast for your city</h2>
        </div>
    );
};

export default Info;