import React from 'react';
import Form from "./Form";
import Weather from "./Weather";
import {apiKey, baseUrl} from "../utils/constants";

class Data extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            weatherInfo: {
                temp: null,
                city: null,
                country: null,
                pressure: null,
                sunset: null,
                error: "Enter your city"
            }
        }
    }

    getWeather = (city) => {
        fetch(`${baseUrl}?q=${city}&appid=${apiKey}&units=metric`)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                this.setState({
                    weatherInfo: {
                        temp: data.main.temp,
                        city: data.name,
                        country: data.sys.country,
                        pressure: data.main.pressure,
                        sunset: data.sys.sunset,
                        error: null
                    }
                })
            })
            .catch(e => {
                this.setState({
                    weatherInfo: {
                        temp: null,
                        city: null,
                        country: null,
                        pressure: null,
                        sunset: null,
                        error: "Enter correct city name"
                    }
                })
            })
    }
    render() {
        return (
            <div>
                <Form getWeather={this.getWeather}/>
                <Weather weather={this.state.weatherInfo}/>
            </div>
        );
    }
}

export default Data;


