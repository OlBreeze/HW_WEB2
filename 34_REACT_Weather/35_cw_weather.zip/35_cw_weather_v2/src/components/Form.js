import React from 'react';
import {apiKey, baseUrl} from "../utils/constants";

const Form = (props) => {

    let handleGetCitySubmit = (event) => {
        event.preventDefault();
        const city = event.currentTarget.city.value.trim();
        console.log(city);
        props.getWeather(city);
    }

    return (
        <form onSubmit={(event) => handleGetCitySubmit(event)}>
            <input type="text" name={'city'} placeholder={'Enter your city'}/>
            <button type={"submit"}>Get Weather</button>
        </form>
    );
};

export default Form;