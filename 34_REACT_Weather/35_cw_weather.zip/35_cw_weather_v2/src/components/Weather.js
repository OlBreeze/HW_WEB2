import React from 'react';

const Weather = ({weather}) => {

    return (
        <div style={{width: '60%', fontSize: '20px', color: '#fff'}}>
            {
              !weather.error &&
              <div>
                  <p>Location: {weather.city}, {weather.country}</p>
                  <p>Temperature: {weather.temp}</p>
                  <p>Pressure: {weather.pressure}</p>
                  <p>Sunset: {new Date(weather.sunset * 1000).toTimeString()}</p>
              </div>
            }
            <h3>{weather.error}</h3>
        </div>
    );
    // if(weather.error)
    //     return(
    //         <div>
    //             <h3>{weather.error}</h3>
    //         </div>
    //     )
    // else
    //     return (
    //         <div>
    //             <p>Location: {weather.city}, {weather.country}</p>
    //             <p>Temperature: {weather.temp}</p>
    //             <p>Pressure: {weather.pressure}</p>
    //             <p>Sunset: {new Date(weather.sunset * 1000).toTimeString()}</p>
    //         </div>
    //     );
};

export default Weather;