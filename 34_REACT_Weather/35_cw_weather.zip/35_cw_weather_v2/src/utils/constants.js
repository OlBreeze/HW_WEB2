
export const baseUrl = 'https://api.openweathermap.org/data/2.5/weather'
export const apiKey = '202e6b9ce38004ad6e2dd5e7ffbab798'