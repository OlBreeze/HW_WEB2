import React from 'react';

const FarGalaxy = () => {
    return (
        <p className="farGalaxy">Title: The Empire Strikes Back
            <br/>
            Episode: 5
            <br/>
            Release_date: 1980-05-17
            <br/>
            It is a dark time for the Rebellion. Although the Death Star has been destroyed, Imperial troops have
            driven
            the
            Rebel forces
            from their hidden base and pursued them across the galaxy. Evading the dreaded Imperial Starfleet, a
            group
            of
            freedom fighters led by Luke Skywalker has established a new secret base on the remote ice world of
            Hoth.
            The
            evil lord Darth Vader, obsessed with finding young Skywalker, has dispatched thousands of remote probes
            into
            the
            far reaches of space.... </p>
    );
};

export default FarGalaxy;