import React from 'react';

const NavItem = ({text}) => { // диструктуризация из props
        return <li className="nav-item border border-light rounded-pill btn btn-danger mx-1 button">{text}</li>
};

export default NavItem;