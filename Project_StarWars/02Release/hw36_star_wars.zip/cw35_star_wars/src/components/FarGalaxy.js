import React from 'react';
import {base_URL, textFarGalaxy} from "../utils/constants";

class FarGalaxy extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            textFarGalaxyLoad: null
        }
    }

    componentDidMount() {
        const episod = Math.floor(Math.random()*6) +1;
        console.log("episod", episod);

        fetch(`${base_URL}v1/films/${episod}`)
            .then(response => response.json())
            .then(data => {
                this.setState({
                    loading: false,
                    textFarGalaxyLoad: data
                })
            })
    }

    render() {
        const content = this.state.loading? "LOADING....": this.state.textFarGalaxyLoad.opening_crawl;

        return (
            <p className="farGalaxy">Title: The Empire Strikes Back
                <br/>
                Episode: 5
                <br/>
                Release_date: 1980-05-17
                <br/>
                {content}
            </p>
        );
    }
}

export default FarGalaxy;