import React from 'react';
import {images} from "../utils/constants";


const Friend = ({imgIndex, imgClass}) => {
    const image = images[`friend${imgIndex}`];

    return <img src={image} alt="friend" className={imgClass}/>
};

export default Friend;