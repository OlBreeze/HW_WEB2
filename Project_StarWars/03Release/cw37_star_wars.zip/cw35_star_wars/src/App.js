
import './App.css';
import Header from "./components/Header";
import Main from "./components/Main";
import Footer from "./components/Footer";
import {Component} from "react";
import {navItems} from "./utils/constants";

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {activePage: navItems[0]}
    }

    changePage = page => this.setState({activePage: page})

    render() {
        /*localStorage.setItem("key", this.state.activePage)
        sessionStorage.setItem("ol", this.state.activePage)*/
        return (
            <div className="container-fluid">
                <Header currentPage={this.state.activePage} changePage={this.changePage}/>
                <Main page={this.state.activePage}/>
                <Footer/>
            </div>
        );
    }
}

export default App;
