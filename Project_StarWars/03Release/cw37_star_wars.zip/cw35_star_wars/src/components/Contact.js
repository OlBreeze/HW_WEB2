import React from 'react';
import style from './contact.module.css';
import {base_URL} from "../utils/constants";

class Contact extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            planets: null
        }
    }

    componentDidMount() {
        const planetsData = localStorage.getItem('planet_data');
        if (planetsData)
            this.setState({
                isLoading: false,
                planets: planetsData.split(',')
            })
        else {
                fetch(`${base_URL}v1/planets`)
                .then(response => response.json())
                .then(data => {
                    const livePlanets = []
                    for (const iPlanet of data) {
                        if (+iPlanet.population>0)
                            livePlanets.push(iPlanet.name)
                    }

                    localStorage.setItem('planet_data', livePlanets.join(','));

                    this.setState({
                        isLoading: false,
                        planets: livePlanets
                    })
                })
                .catch((e) => {
                    console.log("Error:", e)
                    this.setState({
                            isLoading: false,
                            planets: null
                })
            })
        }
    }

    render() {

        let innerOption = [];
        if (this.state.planets === null) {
            innerOption = [
                    <option key={1} value="saleucami">Saleucami</option>,
                    <option key={2} value="sullust">Sullust</option>
                        ];
        } else {
            this.state.planets.forEach((item, index) => {
                innerOption.push(<option key={index} value={item}>{item}</option>);
            });
        }
        //console.log(innerOption)
        return (
            <div className={style.container}>
                    <form action="">
                        <label htmlFor="fname" className={style.label}>First Name</label>
                        <input type="text" id="fname" name="firstname" className={style.inpText}
                               placeholder="Your name.."/>

                        <label htmlFor="lname" className={style.label}>Last Name</label>
                        <input type="text" id="lname" name="lastname" className={style.inpText}
                               placeholder="Your last name.."/>

                        <label htmlFor="planet" className={style.label}>Planet</label>
                        <select id="planet" name="planet" className={style.elSelect}>
                            {innerOption}
                        </select>

                        <label htmlFor="subject" className={style.label}>Subject</label>
                        <textarea id="subject" className={style.elTextarea} name="subject"
                                  placeholder="Write something.."></textarea>

                        <input type="submit" value="Submit" className={style.button}/>

                    </form>
                </div>
            );
    }
}

export default Contact;


/*
let planet_data = {
    /!*id: data.id,
    edited: data.edited,
    climate: data.climate,
    surface_water: data.surface_water,
    name: data.name,
    diameter: data.diameter,
    rotation_period: data.rotation_period,
    created: data.created,
    terrain: data.terrain,
    gravity: data.gravity,
    orbital_period: data.orbital_period,
    population: data.population*!/
}*/
