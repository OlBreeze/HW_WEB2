import React from 'react';

const Footer = () => {
    return (
        <footer className="rounded-bottom-4 align-items-center row">
            <div className="col-2 border border-light rounded-pill btn btn-danger m-2 button">
                <p className="mb-0 py-2">Send me <span className="email">email</span></p>
            </div>
        </footer>
    );
};

export default Footer;