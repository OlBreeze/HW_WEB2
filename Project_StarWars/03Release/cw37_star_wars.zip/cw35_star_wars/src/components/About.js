import React, {Component} from 'react';
import {base_URL} from "../utils/constants";
import ErrorPage from "./ErrorPage";

class About extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            heroData: {}
        }
    }

    componentDidMount() {
        const dateCreate = localStorage.getItem('dateCreate');
        const heroData = localStorage.getItem('hero_data');
        //console.log((Date.now() - (new Date(+dateCreate)).getTime())/ (1000 * 86400))
        //console.log( "=>   "  + (Date.now() - ((new Date(+dateCreate)).getTime()) / (1000 * 86400)));

        if (heroData && ((Date.now() - (new Date(+dateCreate)).getTime())/ (1000 * 86400)<30))
            this.setState({
                isLoading: false,
                heroData: JSON.parse(heroData)
            })

        else {
            let her_number = Math.floor(Math.random() * 80 + 1);
            fetch(`${base_URL}v1/peoples/${her_number}`)
                .then(response => response.json())
                .then(data => {
                    let hero_data = {
                        name: data.name,
                        gender: data.gender,
                        skin_color: data.skin_color,
                        hair_color: data.hair_color,
                        height: data.height,
                        eye_color: data.eye_color,
                        mass: data.mass,
                        birth_year: data.birth_year
                    }

                    localStorage.setItem('dateUser', new Date().toDateString());
                    localStorage.setItem('dateCreate', Date.now().toString());
                    localStorage.setItem('hero_data', JSON.stringify(hero_data));

                    this.setState({
                        isLoading: false,
                        heroData: hero_data
                    })
                }).catch(() => {
                this.setState({
                    isLoading: false,
                    heroData: null
                })
            })
        }
    }

    render() {
        return (
            (!this.state.isLoading && this.state.heroData !== null) ?
                <div>
                    <p>NAME: {this.state.heroData.name}</p>
                    <p>Gender: {this.state.heroData.gender}</p>
                    <p>Skin color: {this.state.heroData.skin_color}</p>
                    <p>Hair color: {this.state.heroData.hair_color}</p>
                    <p>Height: {this.state.heroData.height}</p>
                    <p>Eye color: {this.state.heroData.eye_color}</p>
                    <p>Mass: {this.state.heroData.mass}</p>
                    <p>Birth year: {this.state.heroData.birth_year}</p>
                </div>
                : <ErrorPage/>
        );
    }
}

export default About;


