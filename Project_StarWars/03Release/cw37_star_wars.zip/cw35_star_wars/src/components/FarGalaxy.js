import React from 'react';
import {base_URL} from "../utils/constants";

class FarGalaxy extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            episode: {}
        }
    }

    componentDidMount() {
        const filmData = sessionStorage.getItem('episod_data');

        if (filmData)
            this.setState({
                isLoading: false,
                episode: JSON.parse(filmData)
            })
        else {
            let ep_number = Math.floor(Math.random()*6 + 1);
            fetch(`${base_URL}/v1/films/${ep_number}`)
                .then(response => response.json())
                .then(data => {
                    let ep_data = {
                        title: data.title,
                        episode_id: "Episode: " + data.episode_id,
                        release_date: "Realise date: " + data.release_date,
                        opening_crawl: data.opening_crawl
                    }
                    sessionStorage.setItem('episod_data', JSON.stringify(ep_data))
                    this.setState({
                        isLoading: false,
                        episode: ep_data
                    })
                }).catch(e => {
                this.setState({
                    isLoading: false,
                    episode: {
                        opening_crawl: "Something went wrong!"
                    }
                })
            })
        }
    }

    render() {
        return (
            !this.state.isLoading &&
            <p className="farGalaxy">
                {this.state.episode.episode_id}
                <br/>
                {this.state.episode.title}
                <br/>
                {this.state.episode.release_date}
                <br/>
                {this.state.episode.opening_crawl}
            </p> ||
            <h3>LOADING...</h3>

        );
    }
}

export default FarGalaxy;