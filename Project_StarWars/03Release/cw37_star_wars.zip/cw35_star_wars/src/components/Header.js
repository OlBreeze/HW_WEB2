import React from 'react';
import Navigation from "./Navigation";
import style from './nav.module.css';

const Header = ({currentPage, changePage}) => {
    let nameHero;
    if (currentPage !== "about me") nameHero = '';
    else {
        const heroData = localStorage.getItem('hero_data');
        if (heroData)
            nameHero =  JSON.parse(heroData).name;
    }

    return (
        <header className="rounded-top-4">
            <Navigation changePage={changePage}/>
            <h1 className={`text-center py-4 ${style.head}`}>{nameHero}</h1>
        </header>
    );
};

export default Header;