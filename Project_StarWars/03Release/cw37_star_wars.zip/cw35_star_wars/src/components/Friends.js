import React from 'react';
import Friend from "./Friend";

const Friends = () => {
    let innerImg = [];
    for (let i = 1; i <= 9; i++) {
        const style = (i === 7) ? "col-4 p-1 left" : (i === 9) ? " col-4 p-1 right" : "col-4 p-1";

        innerImg.push(<Friend imgIndex={i} key={i} imgClass={style}/>);
    }

    return (
        <section className="float-end w-50 border border-light rounded-bottom-4 mx-1 row">
            <h3 className="text-center col-12">Dream Team</h3>
            {innerImg}
        </section>
    );
};


/*В JavaScript, при конкатенации строк с JSX элементами, нужно использовать {} для оборачивания JSX элемента в строку.
Кроме того, в React каждому элементу массива, который возвращается в цикле, нужно присвоить уникальный ключ (key).*/
export default Friends;