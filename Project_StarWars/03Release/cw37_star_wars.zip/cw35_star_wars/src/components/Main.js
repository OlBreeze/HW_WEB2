import React from 'react';
import Home from "./Home";
import {navItems} from "../utils/constants";
import About from "./About";
import StarWars from "./StarWars";
import Contact from "./Contact";

const Main = ({page}) => {
   switch (page) {
       case navItems[1]: return  <About/>
       case navItems[2]: return  <StarWars/>
       case navItems[3]: return  <Contact/>
       default: return  <Home/>

   }
}

export default Main;