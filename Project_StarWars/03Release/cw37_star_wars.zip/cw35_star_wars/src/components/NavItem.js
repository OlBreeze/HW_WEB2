import React from 'react';

const NavItem = ({text, changePage}) => { // диструктуризация из props
        return <li className="nav-item border border-light rounded-pill btn btn-danger mx-1 button"
        onClick={()=> changePage(text)}>{text}</li>
};

export default NavItem;