import React, {Component} from 'react';
import Block from "./Block";
import {arrayWinner, bestMoves, bestStep} from "../utils/constants";

class GameArea extends Component {
    constructor(props) {
        super(props);
        this.gameOver = false;
        this.symbolHuman = 'X';
        this.symbolComputer = 'O';
        this.counter = 1;
        this.winsComputer = 0;
        this.winsHuman = 0;
        this.numberSteps = 0;

        this.state = {
            blocks: Array.from({ length: 9 }, () => ({ color: "black", value: null }))};

        /*this.state = {
            blocks: [
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null }
            ]
        }*/

        this.freeBlocks = this.state.blocks.map(block => block.value);
    }

    render() {
        const message = this.gameOver? `Game over!`: `Game ${this.counter}`;
        const rate = `You ${this.winsHuman} : CPU ${this.winsComputer}`
        return (
            <div className={"wrapper"}>
                <h1>{message}</h1>
                <h1>{rate}</h1>
                <div className={'container'}>
                    {this.state.blocks.map((element, index) => (
                        <Block color={element.color} key={index} indexBlock={index} symbol={element.value}
                               playGame={this.handleClick}/>
                    ))}
                </div>
                <button className="glow-on-hover" onClick={this.handleNewGame}>New game</button>
            </div>
        );
    }

    // Метод для начала новой игры
    handleNewGame = () => {
        // Обновляем состояние для начала новой игры
        this.gameOver = false;
        this.counter ++;
        this.numberSteps = 0;
        this.setState({
            blocks: [
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null },
                { color: "black", value: null }
            ]
        });
    };

    handleClick = (index) => {
        if (this.state.blocks[index].value !==null ||this.gameOver)
            return;

        this.setState(prevState => (
            {
                blocks: prevState.blocks.map((el, i) => {
                    if (i === index && el.value === null) {
                        return {...el, value: this.symbolHuman};
                    }
                    return el;
                })
            }
           ))


        this.checkWinner(); //1
        if (!this.gameOver) {

            // comp
            const indexComputer = this.getIndexBlockForComputer(index);
            this.setState((prevState) => (
                {
                    blocks: prevState.blocks.map((el, i) => {
                        /*console.log('set state ' + i + ' & ' + indexComputer + "       -> " + (+i === +indexComputer))*/
                        if (+i === +indexComputer && el.value === null) {
                           /* console.log("$" + indexComputer + " -  " + (el.value))*/
                            return {...el, value: this.symbolComputer};
                        }
                        return el;
                    })
                }
            ));

            this.numberSteps += 2;
            if (this.numberSteps === 9 || this.numberSteps === 10) {

                this.gameOver = true;
                // авто гейм

            }
            if (!this.gameOver)
                    this.checkWinner();
        }
    }


    getIndexBlockForComputer = (indHuman)=> {

        // проверка на ход компьютера
        if (this.winsComputer-this.winsHuman < 3)  { // дать шанс человеку
        for (const [key, value] of Object.entries(bestStep)) {

            for (const arrayBestStep of bestStep[key]){
                if (+key !== indHuman && this.state.blocks[key].value === null
                    && this.state.blocks[arrayBestStep[0]].value === this.symbolComputer
                    && this.state.blocks[arrayBestStep[1]].value === this.symbolComputer) {
                    return key;
                }
            }
        }}
        if (this.winsComputer-this.winsHuman < 3)  { // дать шанс человеку
        const arrayBestSteps = bestStep[indHuman];
        for (const arrayBestStep of arrayBestSteps) { // проверка на человеческий ход

            if (this.state.blocks[arrayBestStep[0]].value !== null&&this.state.blocks[arrayBestStep[1]].value === null&&this.state.blocks[arrayBestStep[0]].value===this.symbolHuman)
                return arrayBestStep[1];


            if (this.state.blocks[arrayBestStep[1]].value !== null&&this.state.blocks[arrayBestStep[0]].value === null&&this.state.blocks[arrayBestStep[1]].value===this.symbolHuman)
                return arrayBestStep[0];

        }}

        if (indHuman!==4 && this.state.blocks[4].value === null)//2-й шаг
            return 4; // это середка

        this.freeBlocks = this.state.blocks.filter(el => el.value === null);
        console.log("массив пустых блоков:  " + this.freeBlocks);

        const arrayBestMoves = bestMoves[indHuman];
        for (const ind of arrayBestMoves) {
            console.log("index "  + ind + ' valueBlocks ' + this.state.blocks[ind].value)
            if (this.state.blocks[ind].value === null)
                return ind;
        }

        return this.freeBlocks[0]; // проверка на 0
    }


    checkWinner() {
        /*if (this.gameOver)
            return true;*/

        this.setState(prevState => {

            const arr = prevState.blocks.map(block => block.value);

            for (let i = 0; i < arrayWinner.length; i++) {
                const [a1, a2, a3] = arrayWinner[i];
                if (arr[a1] && arr[a1] === arr[a2] && arr[a2] === arr[a3]) {
                    if (arr[a1] === this.symbolHuman) {
                        console.log(a1 + " " + a2 + " " + a3 + " / " + this.winsHuman + "  i = " + i)
                        this.winsHuman++;
                    }
                    else
                        this.winsComputer++;

                    this.gameOver = true;

                    const {blocks} = prevState;
                    const updatedBlocks = [...blocks];

                    updatedBlocks[a1].color = 'red';
                    updatedBlocks[a2].color = 'red';
                    updatedBlocks[a3].color = 'red';
                    return {blocks: updatedBlocks}
                }
            }
        })
    }

}

export default GameArea;