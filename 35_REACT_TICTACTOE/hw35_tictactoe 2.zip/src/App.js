import './App.css';
import GameArea from "./components/GameArea";

function App() {

    return (
        <GameArea/>
    );
}

export default App;
